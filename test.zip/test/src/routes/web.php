<?php

use mypackage\test\Http\Controllers;

Route::group(['namespace'=>'mypackage\test\Http\Controllers'], function(){
    Route::get('test', 'TestController@index');
});