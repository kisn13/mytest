<?php

namespace mypackage\test\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

class TestController extends Controller
{
    public function index(){
        echo config('test.name'); exit;
        return view('test::index');
    }
}
